package com.kopo.hello.cafeController;

import com.kopo.hello.cafeService.BaristaService;
import com.kopo.hello.cafeService.OrderService;

import com.kopo.hello.cafeVO.cart.CartItem;
import com.kopo.hello.cafeVO.order.Order;
import com.kopo.hello.cafeVO.order.OrderItem;
import com.kopo.hello.cafeVO.pickUp.PickUp;
import com.kopo.hello.cafeVO.sales.Sales;
import com.kopo.hello.model.PaymentFactory;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.kopo.hello.cafeVO.cart.Cart;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @Autowired
    private PaymentFactory paymentFactory;

    @Autowired
    private BaristaService baristaService;

    @RequestMapping("/complete")
    public String completeOrder(@RequestParam("method") String method, HttpSession session, Model model) {
        // 결제 방식에 따라 주문을 처리하는 로직


        // 세션에서 장바구니와 픽업 정보를 가져옴
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            model.addAttribute("message", "장바구니가 비어 있습니다.");
            return "orderComplete";
        }
        PickUp pickUp = (PickUp) session.getAttribute("pickUpOption");
        Order order = new Order();
        order.setOrderId(orderService.generateOrderId()); // 고유한 orderId 설정
        order.setPickUp(pickUp.getPickUpType());

        ArrayList<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cart.getItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setItemId(cartItem.getItemId());
            orderItem.setName(cartItem.getName());
            orderItem.setPrice(cartItem.getPrice());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setSelectedSize(cartItem.getSelectedSize());
            orderItems.add(orderItem);
        }

        order.setOrderItems(orderItems);
        order.setOrderPrice(order.calculateTotalOrderPrice());

        // 주문 저장 및 처리 로직
        orderService.saveOrder(order);

        // 세션에서 장바구니 제거 또는 초기화
        session.removeAttribute("cart");
        session.removeAttribute("cartItemCount");

        // 주문 완료 페이지로 이동
        model.addAttribute("message", "주문이 완료되었습니다! 결제 방법: " + method);
        model.addAttribute("orderId", order.getOrderId());
        return "orderComplete";
    }
    @RequestMapping("/barista")
    public String viewOrders(Model model) {
        Map<String, Order> orders = orderService.getAllOrders();
        model.addAttribute("orders", orders);
        return "barista";
    }

    @RequestMapping("/barista/process")
    public String processOrder(@RequestParam("orderId") String orderId, @RequestParam("action") String action, Model model) {
//        baristaService.processOrder(orderId, action);
        baristaService.addSalesRecord(orderService.getOrderById(orderId));
        // 완료된 주문은 목록에서 제거
        orderService.removeOrder(orderId);
        return "redirect:/order/barista";
    }

    @RequestMapping("/sales")
    public String viewSales(Model model){
        List<Sales> salesList = baristaService.getAllSales();
        int totalSales = baristaService.calculateTotalSales();

        model.addAttribute("salesList", salesList);
        model.addAttribute("totalSales", totalSales);

        return "totalSales";
    }

}
