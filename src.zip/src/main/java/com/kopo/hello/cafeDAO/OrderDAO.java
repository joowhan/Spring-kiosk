package com.kopo.hello.cafeDAO;

import com.kopo.hello.cafeVO.order.Order;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class OrderDAO {
    // 메모리 내의 주문 저장소
    private final Map<String, Order> orderStore = new HashMap<>();

    // 주문 저장
    public void saveOrder(Order order) {
        orderStore.put(order.getOrderId(), order);
    }

    // 특정 주문 조회
    public Order getOrderById(String orderId) {
        return orderStore.get(orderId);
    }

    // 모든 주문 조회 (예시로 추가)
    public Map<String, Order> getAllOrders() {
        return orderStore;
    }


    // 제거
    public void deleteOrderById(String orderId){
        if (orderStore.containsKey(orderId)) {
            orderStore.remove(orderId);
            System.out.println("Order with ID: " + orderId + " has been deleted.");
        } else {
            System.out.println("Order with ID: " + orderId + " not found.");
        }
    }

}
