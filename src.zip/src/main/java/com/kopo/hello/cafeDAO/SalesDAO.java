package com.kopo.hello.cafeDAO;

import com.kopo.hello.cafeVO.sales.Sales;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SalesDAO {

    private Map<String, Sales> salesData = new HashMap<>();

    public Sales findSalesRecordByItemId(String itemId) {
        return salesData.get(itemId);
    }

    public void updateSalesRecord(Sales record) {
        salesData.put(record.getItemId(), record);
    }

    public void insertSalesRecord(Sales record) {
        salesData.put(record.getItemId(), record);
    }
    // 모든 판매 기록을 반환하는 메서드
    public List<Sales> getAllSales() {
        return new ArrayList<>(salesData.values());
    }

}
