package com.kopo.hello.model;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kopo.hello.cafeService.ApplePayPaymentService;
import com.kopo.hello.cafeService.CardPaymentService;
import com.kopo.hello.cafeService.CashPaymentService;
import com.kopo.hello.cafeService.PaymentService;

@Component
public class PaymentFactory {
    private final Map<String, PaymentService> paymentServices = new HashMap<>();

    @Autowired
    public PaymentFactory(
    		CardPaymentService cardPaymentService, 
            ApplePayPaymentService applePayPaymentService, 
            CashPaymentService cashPaymentService) {
        paymentServices.put("credit", cardPaymentService);
        paymentServices.put("applepay", applePayPaymentService);
        paymentServices.put("cash", cashPaymentService);
    }

    public PaymentService getPaymentService(String method) {
        return paymentServices.get(method);
    }
}
