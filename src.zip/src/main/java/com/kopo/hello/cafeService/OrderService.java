package com.kopo.hello.cafeService;

import com.kopo.hello.cafeDAO.OrderDAO;
import com.kopo.hello.cafeVO.order.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class OrderService {
	/*
	AtomicLong은 멀티 스레드 환경에서 원자적으로
  	(long 변수의 값을 변경하는 동작이 원자적으로 실행되어 스레드간의 경쟁이 없도록 보장해주는)
	연산을 수행할 수 있도록 도와주는 클래스
	*/
	private static final AtomicLong orderIdCounter = new AtomicLong(0);

	@Autowired
	private OrderDAO orderDAO;

	// 고유한 orderId 생성 메소드
	public String generateOrderId() {
		long nextOrderId = orderIdCounter.incrementAndGet();
		return String.format("%03d", nextOrderId); // 001, 002 형식으로 생성
	}
	// 주문 저장
	public void saveOrder(Order order) {
		orderDAO.saveOrder(order);
	}

	// 특정 주문 조회
	public Order getOrderById(String orderId) {
		return orderDAO.getOrderById(orderId);
	}

	// 모든 주문 조회 (예시로 추가)
	public Map<String, Order> getAllOrders() {
		return orderDAO.getAllOrders();
	}

	// 주문 처리
	public void removeOrder(String orderId) {
		// OrderDAO에서 주문 제거
		orderDAO.deleteOrderById(orderId);
	}
}
