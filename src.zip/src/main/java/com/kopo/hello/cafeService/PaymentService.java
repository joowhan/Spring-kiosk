package com.kopo.hello.cafeService;

//결제 방식 확장을 위한 인터페이스
public interface PaymentService {
	public String paymentWay();
}
