package com.kopo.hello.cafeService;

import org.springframework.stereotype.Service;

import com.kopo.hello.cafeService.PaymentService;

@Service("cardPaymentService")
public class CardPaymentService implements PaymentService {
	
	// 카드 처리 로직 작성
	@Override
	public String paymentWay() {
		// TODO Auto-generated method stub
		return "신용카드를 투입하세요.";
	}


}
