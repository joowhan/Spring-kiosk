package com.kopo.hello.cafeService;

import com.kopo.hello.cafeDAO.SalesDAO;
import com.kopo.hello.cafeVO.order.Order;
import com.kopo.hello.cafeVO.order.OrderItem;
import com.kopo.hello.cafeVO.sales.Sales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BaristaService {
    private final SalesDAO salesDAO;
    @Autowired
    public BaristaService(SalesDAO salesDAO){
        this.salesDAO = salesDAO;
    }
    public void addSalesRecord(Order order) {
        for (OrderItem item : order.getOrderItems()) {
            // 기존 매출 기록을 조회
            Sales existingRecord = salesDAO.findSalesRecordByItemId(item.getItemId());
            if (existingRecord != null) {
                // 기존 기록이 있으면 판매 수량과 매출을 업데이트
                existingRecord.setQuantity(existingRecord.getQuantity() + item.getQuantity());
                existingRecord.setTotalSales(existingRecord.getTotalSales() + item.calculateTotalPrice());
                salesDAO.updateSalesRecord(existingRecord);
            } else {
                // 새로운 판매 기록 추가
                Sales newRecord = new Sales(item.getItemId(), item.getName(), item.getQuantity(), item.calculateTotalPrice());
                salesDAO.insertSalesRecord(newRecord);
            }
        }
    }

    public List<Sales> getAllSales() {
        return salesDAO.getAllSales();
    }

    public int calculateTotalSales() {
        int total = 0;
        for (Sales sales : salesDAO.getAllSales()) {
            total += sales.getTotalSales();
        }
        return total;
    }

}
