package com.kopo.hello.cafeService;

import org.springframework.stereotype.Service;

import com.kopo.hello.cafeService.PaymentService;

@Service("cashPaymentService")
public class CashPaymentService implements PaymentService {

	//현금 계산 로직 작성
	@Override
	public String paymentWay() {
		// TODO Auto-generated method stub
		return "현금을 계산하세요.";
	}

}
