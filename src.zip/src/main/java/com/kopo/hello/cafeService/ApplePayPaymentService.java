package com.kopo.hello.cafeService;

import org.springframework.stereotype.Service;

import com.kopo.hello.cafeService.PaymentService;

@Service("applePayPaymentService")
public class ApplePayPaymentService implements PaymentService {
	
	//애플페이 처리 로직 작성
	@Override
	public String paymentWay() {
		// TODO Auto-generated method stub
		return "핸드폰을 갖다 대세요.";
	}

}
