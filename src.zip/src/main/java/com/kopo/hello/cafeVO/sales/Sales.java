package com.kopo.hello.cafeVO.sales;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Sales {
    private String itemId;
    private String name;
    private int quantity;
    private int totalSales;
    public Sales(String itemId, String name, int quantity, int totalSales) {
        this.itemId = itemId;
        this.name = name;
        this.quantity = quantity;
        this.totalSales = totalSales;
    }

}
