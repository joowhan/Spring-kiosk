package com.kopo.hello.cafeVO.pickUp;

//픽업 방식 선택
public interface PickUp {
	String getPickUpType();
}
